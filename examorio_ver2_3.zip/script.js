// Examorio quiz engine

const SHEET_URL = 'https://script.google.com/macros/s/AKfycbxPgnfeiHKtJZ2x_y3ZEopgx1rzOrh1ksq0rmra9BIFBk_aBILohngFViARGkZuQwWW7w/exec';   // endpoint για ερωτήσεις
const ANSWERS_URL = 'https://script.google.com/macros/s/AKfycbx2cZydB4HWruvp9gW4Nu5tCgipjDcSbCJ5sgxpeLJulLcKxicuwb--xDd8pVGtEw5Q3A/exec'; // endpoint για αποθήκευση απαντήσεων

const EXTRACTS = {
  A: 'images/extractA.png',
  B: 'images/extractB.png'
};

let questions = [];
let currentIndex = 0;
let hasAnsweredCurrent = false;
let currentStudent = null;

const loadingEl = document.getElementById('loading');
const loadingOverlayEl = document.getElementById('loadingOverlay');
const cardEl = document.getElementById('questionCard');
const questionNumberEl = document.getElementById('questionNumber');
const questionTextEl = document.getElementById('questionText');
const extractHolderEl = document.getElementById('extractHolder');
const answersEl = document.getElementById('answers');
const feedbackEl = document.getElementById('feedback');

const prevBtn = document.getElementById('prevQuestion');
const timerEl = document.getElementById('timerDisplay');
let timerSeconds = 90 * 60;
let timerIntervalId = null;
let loadingBarIntervalId = null;
let timerStarted = false;

const nextBtn = document.getElementById('nextQuestion');
const finishBtn = document.getElementById('finishButton');

// login elements
const loginOverlay = document.getElementById('loginOverlay');
const loginButton = document.getElementById('loginButton');
const studentNameInput = document.getElementById('studentName');
const studentCodeInput = document.getElementById('studentCode');
const studentPhoneInput = document.getElementById('studentPhone');

// graph modal
const graphImg = document.getElementById('progressGraph');
const mediaWrap = document.querySelector('.media-wrap');
const graphModalImg = document.getElementById('graphModalImg');
const graphModal = document.getElementById('graphModal');
const graphCloseBtn = document.querySelector('.graph-close');
const graphBackdrop = graphModal.querySelector('.modal-backdrop');

// extract modal
const extractModal = document.getElementById('extractModal');
const extractModalImg = document.getElementById('extractModalImg');
const extractCloseBtn = document.querySelector('.extract-close');
const extractBackdrop = extractModal.querySelector('.modal-backdrop');

function openGraphModal() {
  if (graphModalImg && graphImg && graphImg.src) {
    graphModalImg.src = graphImg.src;
  }
  graphModal.classList.remove('hidden');
  graphModal.setAttribute('aria-hidden', 'false');
}

function closeGraphModal() {
  graphModal.classList.add('hidden');
  graphModal.setAttribute('aria-hidden', 'true');
}

graphImg.addEventListener('click', () => {
  if (!graphImg.src) return;
  openGraphModal();
});
graphCloseBtn.addEventListener('click', closeGraphModal);
graphBackdrop.addEventListener('click', closeGraphModal);

function openExtractModal(extractKey) {
  const url = EXTRACTS[extractKey];
  if (!url) return;
  extractModalImg.src = url;
  extractModal.classList.remove('hidden');
  extractModal.setAttribute('aria-hidden', 'false');
}

function closeExtractModal() {
  extractModal.classList.add('hidden');
  extractModal.setAttribute('aria-hidden', 'true');
}

extractCloseBtn.addEventListener('click', closeExtractModal);
extractBackdrop.addEventListener('click', closeExtractModal);

// login helpers

function loadStudentFromStorage() {
  try {
    const raw = localStorage.getItem('examorio_student');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (_) {
    return null;
  }
}

function saveStudentToStorage(student) {
  try {
    localStorage.setItem('examorio_student', JSON.stringify(student));
  } catch (_) {}
}

function finishLogin(student) {
  currentStudent = student;
  saveStudentToStorage(student);
  loginOverlay.classList.add('hidden');
  loadQuestions();
}

loginButton.addEventListener('click', () => {
  const name = studentNameInput.value.trim();
  const code = studentCodeInput.value.trim();
  const phone = studentPhoneInput.value.trim();

  if (!name || !code) {
    alert('Γράψε όνομα και κωδικό');
    return;
  }

  const student = { name, code, phone };
  finishLogin(student);
});

function formatTime(total){
  const m = Math.floor(total/60);
  const s = total%60;
  return `${m}:${String(s).padStart(2,'0')}`;
}


function computeStats(){
  const total = questions.length || 0;
  let answered = 0;
  let correct = 0;
  let wrong = 0;

  questions.forEach((q) => {
    const st = loadLocalAnswer(q.id || '');
    if (!st) return;

    if (st.type === 'mcq') {
      answered += 1;
      if (st.isCorrect) correct += 1;
      else wrong += 1;
      return;
    }

    if (st.type === 'text') {
      const txt = (st.answerText || '').trim();
      if (txt.length) answered += 1;
    }
  });

  const used = (90 * 60) - timerSeconds;
  const percent = total ? Math.round((correct / total) * 100) : 0;

  return { total, answered, correct, wrong, used, percent };
}

function showResultsOverlay(reason){
  if (!resultsOverlay) return;

  const stats = computeStats();
  const reasonText = reason === 'time' ? 'Τέλος χρόνου ⏰' : 'Τέλος test ✅';
  if (resultsReasonEl) resultsReasonEl.textContent = reasonText;

  if (resultsSummaryEl) {
    resultsSummaryEl.innerHTML =
      `<div>Συνολικές ερωτήσεις: <strong>${stats.total}</strong></div>` +
      `<div>Απαντημένες: <strong>${stats.answered}</strong></div>` +
      `<div>Σωστές: <strong>${stats.correct}</strong> · Λάθος: <strong>${stats.wrong}</strong></div>` +
      `<div>Ποσοστό: <strong>${stats.percent}%</strong></div>` +
      `<div>Χρόνος που χρησιμοποίησες: <strong>${formatTime(Math.max(0, stats.used))}</strong></div>`;
  }

  const frameInner = document.querySelector('.frame-inner');
  if (frameInner) frameInner.classList.add('fade-out');

  setTimeout(() => {
    if (frameInner) frameInner.classList.remove('fade-out');
    resultsOverlay.classList.remove('is-hidden');
    resultsOverlay.setAttribute('aria-hidden', 'false');
  }, 320);
}

function hideResultsOverlay(){
  if (!resultsOverlay) return;
  resultsOverlay.setAttribute('aria-hidden', 'true');
  resultsOverlay.classList.add('is-hidden');
}

function startTimer(){
  if(!timerEl) return;
  if (timerStarted) return;
  timerStarted = true;
  timerEl.textContent = formatTime(timerSeconds);
  timerIntervalId = setInterval(()=>{
    if(timerSeconds<=0){
      clearInterval(timerIntervalId);
      timerIntervalId = null;
      showResultsOverlay('time');
      return;
    }
    timerSeconds -= 1;
    timerEl.textContent = formatTime(timerSeconds);
  },1000);
}

function showLoadingOverlay(){
  if (!loadingOverlay) return;
  loadingOverlay.classList.remove('is-hidden');
  loadingOverlay.setAttribute('aria-hidden', 'false');

  if (loadBarInner) {
    let p = 0;
    loadBarInner.style.width = '0%';
    if (loadingBarIntervalId) clearInterval(loadingBarIntervalId);
    loadingBarIntervalId = setInterval(() => {
      p += 5;
      if (p > 90) p = 40;
      loadBarInner.style.width = p + '%';
    }, 200);
  }
}


function hideLoadingOverlay(){
  if (!loadingOverlay) return Promise.resolve();
  loadingOverlay.setAttribute('aria-hidden', 'true');

  if (loadingBarIntervalId) {
    clearInterval(loadingBarIntervalId);
    loadingBarIntervalId = null;
  }
  if (loadBarInner) {
    loadBarInner.style.width = '100%';
  }

  // smooth fade out like old ARUNNER
  return new Promise(resolve => {
    setTimeout(() => {
      loadingOverlay.classList.add('is-hidden');
      resolve();
    }, 220);
  });
}


function revealQuestionCard(){
  if (!cardEl) return;
  cardEl.classList.remove('hidden');
  // allow DOM paint then animate in
  requestAnimationFrame(() => {
    cardEl.classList.add('show');
  });
}

window.addEventListener('DOMContentLoaded', () => {
  const saved = loadStudentFromStorage();
  if (saved) {
    finishLogin(saved);
  }
});

// nav helpers

function updateNavButtons() {
  prevBtn.disabled = currentIndex === 0;
  nextBtn.disabled = currentIndex === questions.length - 1;
}

function goToNextQuestion() {
  if (currentIndex < questions.length - 1) {
    currentIndex += 1;
    renderQuestion();
  }
}

function goToPrevQuestion() {
  if (currentIndex > 0) {
    currentIndex -= 1;
    renderQuestion();
  }
}

nextBtn.addEventListener('click', goToNextQuestion);
prevBtn.addEventListener('click', goToPrevQuestion);

// keyboard arrows
document.addEventListener('keydown', (event) => {
  if (event.key === 'ArrowRight') {
    goToNextQuestion();
  } else if (event.key === 'ArrowLeft') {
    goToPrevQuestion();
  }
});

// send answers to backend

async function sendAnswerToServer(payload) {
  if (!ANSWERS_URL || !currentStudent) return;

  const fullPayload = {
    ...payload,
    student: currentStudent
  };

  try {
    await fetch(ANSWERS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fullPayload)
    });
  } catch (err) {
    console.error('Error sending answer', err);
  }
}


function studentKeyPrefix(){
  const code = (currentStudent && currentStudent.code) ? currentStudent.code : 'anon';
  return `examorio_${code}_`;
}

function loadLocalAnswer(questionId){
  try{
    const raw = localStorage.getItem(studentKeyPrefix() + 'ans_' + questionId);
    if(!raw) return null;
    return JSON.parse(raw);
  }catch(_){ return null; }
}

function saveLocalAnswer(questionId, data){
  try{
    localStorage.setItem(studentKeyPrefix() + 'ans_' + questionId, JSON.stringify(data));
  }catch(_){}
}



// rendering

function renderQuestion() {
  if (!questions.length) return;

  const q = questions[currentIndex];

  questionNumberEl.textContent = `Q${currentIndex + 1} / ${questions.length}`;
    questionTextEl.textContent = q.question || '';

  // image per question
  const imgUrl = (q.imageUrl || '').trim();
  if (mediaWrap && graphImg) {
    if (imgUrl) {
      graphImg.src = imgUrl;
      mediaWrap.classList.remove('hidden');
    } else {
      graphImg.src = '';
      mediaWrap.classList.add('hidden');
    }
  }

  extractHolderEl.innerHTML = '';
  answersEl.innerHTML = '';
  feedbackEl.textContent = '';
  hasAnsweredCurrent = false;

  renderExtractButton(q);

  if (q.type === 'text') {
    renderTextQuestion(q);
  } else {
    renderMcqQuestion(q);
  }

  updateNavButtons();
}

function renderExtractButton(q) {
  if (!q.extraData || !q.extraData.extract) return;

  const key = q.extraData.extract;
  if (!EXTRACTS[key]) return;

  const wrap = document.createElement('div');
  wrap.className = 'extract-wrap';

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'extract-button';
  btn.textContent = `View Extract ${key}`;

  btn.addEventListener('click', () => openExtractModal(key));

  wrap.appendChild(btn);
  extractHolderEl.appendChild(wrap);
}

function renderMcqQuestion(q) {
  const saved = loadLocalAnswer(q.id || '');
  const savedIndex = saved && typeof saved.selectedIndex === 'number' ? saved.selectedIndex : null;
  q.answers.forEach((answerText, index) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'answer-option';
    btn.textContent = answerText;

    btn.addEventListener('click', () => {
      if (hasAnsweredCurrent) return;
      hasAnsweredCurrent = true;
      const correctIndex = q.correctIndex;
      const isCorrect = index === correctIndex;

      if (isCorrect) {
        btn.classList.add('correct');
        feedbackEl.textContent = q.explanation || 'Correct.';
      } else {
        btn.classList.add('wrong');
        feedbackEl.textContent = q.explanation || 'Check the model answer and try again.';
        const answerButtons = answersEl.querySelectorAll('.answer-option');
        if (answerButtons[correctIndex]) {
          answerButtons[correctIndex].classList.add('correct');
        }
      }

      saveLocalAnswer(q.id || '', {
        type: 'mcq',
        selectedIndex: index,
        selectedText: answerText,
        isCorrect,
        timestamp: new Date().toISOString()
      });

      const payload = {
        type: 'mcq',
        questionId: q.id || '',
        topic: q.topic || '',
        question: q.question || '',
        selectedIndex: index,
        selectedText: answerText,
        correctIndex,
        correctText: q.answers[correctIndex],
        isCorrect,
        explanation: q.explanation || '',
        timestamp: new Date().toISOString()
      };

      sendAnswerToServer(payload);
    });

    answersEl.appendChild(btn);
  });

  if (savedIndex !== null) {
    const buttons = answersEl.querySelectorAll('.answer-option');
    if (buttons[savedIndex]) {
      hasAnsweredCurrent = true;
      const correctIndex = q.correctIndex;
      const isCorrect = savedIndex === correctIndex;
      buttons[savedIndex].classList.add(isCorrect ? 'correct' : 'wrong');
      if (!isCorrect && buttons[correctIndex]) buttons[correctIndex].classList.add('correct');
      feedbackEl.textContent = q.explanation || (isCorrect ? 'Correct.' : 'Check the model answer and try again.');
    }
  }
}

function renderTextQuestion(q) {
  const textarea = document.createElement('textarea');
  const saved = loadLocalAnswer(q.id || '');
  if (saved && saved.answerText) {
    textarea.value = saved.answerText;
  }

  textarea.className = 'text-answer';
  textarea.rows = 5;
  textarea.placeholder = 'Γράψε την απάντηση σου εδώ';

  answersEl.appendChild(textarea);

  // auto-save (local + server) with debounce
  let saveTimeout = null;
  let lastSent = '';

  textarea.addEventListener('input', () => {
    const textNow = textarea.value;
    saveLocalAnswer(q.id || '', {
      type: 'text',
      answerText: textNow,
      savedToServer: false,
      timestamp: new Date().toISOString()
    });

    if (saveTimeout) clearTimeout(saveTimeout);
    saveTimeout = setTimeout(() => {
      const text = (textarea.value || '').trim();
      if (!text) return;
      if (text === lastSent) return;
      lastSent = text;

      const payload = {
        type: 'text',
        questionId: q.id || '',
        topic: q.topic || '',
        question: q.question || '',
        answerText: text,
        modelAnswer: q.explanation || '',
        timestamp: new Date().toISOString()
      };

      sendAnswerToServer(payload);
    }, 900);
  });
}

// data

function parseExtraData(raw) {
  if (!raw) return {};
  if (typeof raw === 'object') return raw;
  try {
    return JSON.parse(raw);
  } catch (_) {
    return {};
  }
}

function getFallbackQuestions() {
  return [
    {
      id: 'q1',
      type: 'mcq',
      topic: 'Demand and supply',
      question: 'What happens to equilibrium price if demand increases and supply stays the same',
      answers: [
        'Price and quantity both increase',
        'Price falls and quantity rises',
        'Price rises and quantity falls',
        'Price and quantity both fall'
      ],
      correctIndex: 0,
      explanation: 'When demand shifts right and supply is unchanged both equilibrium price and quantity rise.',
      extraData: {},
      imageUrl: ''
    },
    {
      id: 'q2',
      type: 'text',
      topic: 'Elasticity',
      question: 'Explain why goods with many close substitutes tend to have price elastic demand',
      answers: [],
      correctIndex: 0,
      explanation: 'When there are many substitutes consumers can easily switch when price changes so the percentage change in quantity demanded is larger than the percentage change in price.',
      extraData: { extract: 'A' }
    }
  ];
}

async function loadQuestions() {
  try {
    showLoadingOverlay();
    loadingEl.classList.remove('hidden');
    loadingEl.setAttribute('aria-hidden', 'false');
    cardEl.classList.add('hidden');
    cardEl.classList.remove('show');

    if (SHEET_URL) {
      const response = await fetch(SHEET_URL);
      const data = await response.json();

      const rows = Array.isArray(data) ? data : (data.items || []);

      questions = (rows || []).map((row, index) => {
        const rawType = (row.type || 'mcq').toString().toLowerCase();
        const qType = rawType === 'text' ? 'text' : 'mcq';

        return {
          id: row.id || `q${index + 1}`,
          type: qType,
          topic: row.topic || '',
          question: row.question || '',
          answers: [row.answerA, row.answerB, row.answerC, row.answerD].filter(Boolean),
          correctIndex: Number(row.correctIndex ?? 0),
          explanation: row.explanation || '',
          extraData: parseExtraData(row.extraData),
          imageUrl: row.imageUrl || ''
        };
      });
    } else {
      questions = getFallbackQuestions();
    }

    loadingEl.classList.add('hidden');
    loadingEl.setAttribute('aria-hidden', 'true');

    currentIndex = 0;
    renderQuestion();

    // hide overlay first then start timer and fade in (ARUNNER behavior)
    await hideLoadingOverlay();
    startTimer();
    revealQuestionCard();
  } catch (err) {
    console.error(err);
    loadingEl.textContent = 'Error loading questions.';
  }
}


if (finishBtn) {
  finishBtn.addEventListener('click', () => {
  closeGraphModal();
  closeExtractModal();
  showResultsOverlay('manual');
});
}


// results overlay buttons
if (resultsRestartBtn) {
  resultsRestartBtn.addEventListener('click', () => location.reload());
}
if (resultsCloseBtn) {
  resultsCloseBtn.addEventListener('click', () => {
    hideResultsOverlay();
    loginOverlay.classList.remove('hidden');
  });
}
